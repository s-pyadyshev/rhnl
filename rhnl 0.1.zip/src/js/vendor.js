require("./vendor/fancyselect");
import $ from "jquery";

window.$ = $;
window.jQuery = $;
